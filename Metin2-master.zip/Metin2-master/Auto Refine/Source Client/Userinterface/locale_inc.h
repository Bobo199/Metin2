// 0.1 Add :

#define ENABLE_REFINE_RENEWAL
