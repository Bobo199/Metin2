// 0.1 Search :
	PyModule_AddIntConstant(poModule, "DS_WHITE",							CItemData::DS_SLOT1);
	
// Add upper :

	PyModule_AddIntConstant(poModule, "ITEM_TYPE_GIFTBOX",					CItemData::ITEM_TYPE_GIFTBOX);

	