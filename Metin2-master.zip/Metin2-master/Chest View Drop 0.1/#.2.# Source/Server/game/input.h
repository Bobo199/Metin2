// 1. Search:
		void		Refine(LPCHARACTER ch, const char* c_pData);
// 1. Add after:		
#ifdef ENABLE_SHOW_CHEST_DROP
		void		ChestDropInfo(LPCHARACTER ch, const char * c_pData);
#endif