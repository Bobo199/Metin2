//1. Search:
#include "PhysicsObject.h"
//1. Add after
#include "../UserInterface/Locale_inc.h"


//2. Search:
		CArea::TCRCWithNumberVector & GetRenderedGraphicThingInstanceNum(DWORD * pdwGraphicThingInstanceNum, DWORD * pdwCRCNum);
//2. Add after
#ifdef ENABLE_FOG_FIX
		void	SetEnvironmentFog(bool flag);
#endif