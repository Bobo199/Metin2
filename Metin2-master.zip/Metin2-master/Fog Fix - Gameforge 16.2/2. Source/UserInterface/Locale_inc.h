//1. Add:
#define ENABLE_FOG_FIX