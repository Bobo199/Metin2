///caut�:
	COSTUME_HAIR = ARMOR_HEAD,

///adaug�:
#ifdef ENABLE_MOUNT_COSTUME_SYSTEM
	COSTUME_MOUNT,
#endif