///caut�:
		bool		IsNewMountItem();

///adaug�:
#ifdef ENABLE_MOUNT_COSTUME_SYSTEM
		bool		IsMountItem();
#endif
