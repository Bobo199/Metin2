///caut�:
				if (!pChar->IsPet() && (true == pChar->IsMonster() || true == pChar->IsStone()))

///modific�:
				if (!pChar->IsPet() && !pChar->IsMount() && (true == pChar->IsMonster() || true == pChar->IsStone()))
