//ADD :

#define ENABLE_MOVE_CHANNEL
