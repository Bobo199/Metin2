				{
					"name" : "logout_button",
					"type" : "button",

					"x" : 10,
					"y" : 180,

					"text" : uiScriptLocale.SYSTEM_LOGOUT,

					"default_image" : ROOT + "XLarge_Button_01.sub",
					"over_image" : ROOT + "XLarge_Button_02.sub",
					"down_image" : ROOT + "XLarge_Button_03.sub",
				},
				
#ADD THIS AFTER : 	 logout_button		
				{
					"name" : "movechannel_button",
					"type" : "button",

					"x" : 10,
					"y" : 150,

					"text" : uiScriptLocale.SYSTEM_MOVE_CHANNEL,

					"default_image" : ROOT + "XLarge_Button_01.sub",
					"over_image" : ROOT + "XLarge_Button_02.sub",
					"down_image" : ROOT + "XLarge_Button_03.sub",
				},