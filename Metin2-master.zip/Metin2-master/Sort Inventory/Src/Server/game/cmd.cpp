///caut�:
// REFINE_PICK

///adaug�:
ACMD(do_sort_items);

///caut�:
	// REFINE_PICK

///adaug�:
	{ "click_sort_items",	do_sort_items,	0,	POS_DEAD,	GM_PLAYER	},