// Search:
		const char*			GetMonsterName(DWORD dwVnum);
// Add after:
		bool 				MonsterHasRaceFlag(DWORD dwVnum, const char * szSearchString);